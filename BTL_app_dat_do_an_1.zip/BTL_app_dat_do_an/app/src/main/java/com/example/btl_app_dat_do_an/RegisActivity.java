package com.example.btl_app_dat_do_an;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.btl_app_dat_do_an.dal.SQLiteHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.ktx.Firebase;

public class RegisActivity extends AppCompatActivity {
    EditText editTextUsername, editTextPassword;
    Button buttonRegisRe, buttonLoginRe;
    SQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regis);

        editTextUsername = findViewById(R.id.username1);
        editTextPassword = findViewById(R.id.password1);
        buttonRegisRe = findViewById(R.id.btRegisRe);
        buttonLoginRe = findViewById(R.id.btLoginRe);
        db = new SQLiteHelper(this);

        buttonLoginRe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisActivity.this,LoginActivity.class);
                startActivity(intent);
            }
        });

        buttonRegisRe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = String.valueOf(editTextUsername.getText());
                String password = String.valueOf(editTextPassword.getText());
                String role = "Customer";

                if(TextUtils.isEmpty(username)){
                    Toast.makeText(RegisActivity.this,"Không để trống username",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    Toast.makeText(RegisActivity.this,"Không để trống password",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    boolean checkUser = db.checkUsername(username);
                    if(!checkUser){
                        boolean insert = db.insertUser(username,password,role);
                        if (insert){
                            Toast.makeText(RegisActivity.this, "Đăng kí thành công.",Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(RegisActivity.this, "Đăng kí thất bại.",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisActivity.this, "Tên tài khoản đã tồn tại.",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}