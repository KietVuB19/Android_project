package com.example.btl_app_dat_do_an.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Login.db";
    private static final int DATABASE_VERSION = 1;
    public SQLiteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "Create table users(username TEXT primary key," +
                "password text," +
                "role text)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertUser(String username, String password, String role){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("role",role);
        long result = db.insert("users",null,contentValues);
        return result != -1;
    }


    public boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *from users where username = ?",new String[]{username});
        return cursor.getCount() > 0;
    }

    public boolean checkAccount(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *from users where username = ? and password = ?",new String[]{username,password});
        return cursor.getCount() > 0;
    }

    public boolean checkAdmin(String username, String password, String role){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *from users where username = ? and password = ? and role = ADMIN",new String[]{username,password,role});
        return cursor.getCount() > 0;
    }
}
