package com.example.btl_app_dat_do_an.dal;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteHelperAdmin extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Food.db";
    private static final int DATABASE_VERSION = 1;

    public SQLiteHelperAdmin(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "Create table items(Id Interger primary key autoincrement," +
                "name text, category text, price text, date text)";
        db.execSQL(sql);
    }

    @Override 
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
