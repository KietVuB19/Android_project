package com.example.btl_app_dat_do_an.model;

import java.io.Serializable;

public class Item implements Serializable {
    private int id;
    private String name, describe, price, date;

    public Item() {
    }

    public Item(int id, String name, String describe, String price, String date) {
        this.id = id;
        this.name = name;
        this.describe = describe;
        this.price = price;
        this.date = date;
    }

    public Item(String name, String describe, String price, String date) {
        this.name = name;
        this.describe = describe;
        this.price = price;
        this.date = date;
    }

    public Item(int id, String name, String describe, String price) {
        this.id = id;
        this.name = name;
        this.describe = describe;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {this.describe = this.describe; }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
