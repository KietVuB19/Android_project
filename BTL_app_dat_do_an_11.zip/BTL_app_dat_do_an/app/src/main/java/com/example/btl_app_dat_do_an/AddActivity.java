package com.example.btl_app_dat_do_an;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.btl_app_dat_do_an.dal.SQLiteHelperItem;
import com.example.btl_app_dat_do_an.model.Item;

public class AddActivity extends AppCompatActivity {

    private EditText eName, eDes, ePrice, eDate;
    private Button btAdd, btCancel;

    SQLiteHelperItem sqLiteHelperItem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        eName = findViewById(R.id.tvNameAdd);
        eDes = findViewById(R.id.tvDescribeAdd);
        ePrice = findViewById(R.id.tvPriceAdd);
        eDate = findViewById(R.id.tvDateAdd);
        btAdd = findViewById(R.id.btItemAdd);
        btCancel = findViewById(R.id.btItemAddCancel);
        sqLiteHelperItem = new SQLiteHelperItem(this);

        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = String.valueOf(eName.getText());
                String des = String.valueOf(eDes.getText());
                String price = String.valueOf(ePrice.getText());
                String date = String.valueOf(eDate.getText());
                if(name.isEmpty() || des.isEmpty() || price.isEmpty() || date.isEmpty()){
                    Toast.makeText(AddActivity.this,"Hãy nhập đủ các ô còn trống",Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    Item i = new Item(name,des,price,date);
                    sqLiteHelperItem.addItem(i);
                    Toast.makeText(AddActivity.this,"Thêm sản phẩm thành công",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}