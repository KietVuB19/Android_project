package com.example.btl_app_dat_do_an;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.btl_app_dat_do_an.dal.SQLiteHelper;

public class LoginActivity extends AppCompatActivity {
    EditText editTextUsername, editTextPassword;
    Button buttonRegis, buttonLogin;
    SQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.username);
        editTextPassword = findViewById(R.id.password);
        buttonLogin = findViewById(R.id.btLogin);
        buttonRegis = findViewById(R.id.btRegis);
        db = new SQLiteHelper(this);

        buttonRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,RegisActivity.class);
                startActivity(intent);
            }
        });

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = String.valueOf(editTextUsername.getText());
                String password = String.valueOf(editTextPassword.getText());
//                String role = "";

                if(username.equals("")){
                    Toast.makeText(LoginActivity.this,"Không để trống username",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(password.equals("")){
                    Toast.makeText(LoginActivity.this,"Không để trống password",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    boolean checkLogin = db.checkAccount(username,password);
                    if(checkLogin){
                            Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                            startActivity(intent);
                    }
                    else{
                        Toast.makeText(LoginActivity.this,"Nhập sai tài khoản hoặc mật khẩu",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}