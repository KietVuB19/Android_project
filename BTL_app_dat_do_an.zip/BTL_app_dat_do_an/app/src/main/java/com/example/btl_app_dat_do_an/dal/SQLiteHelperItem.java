package com.example.btl_app_dat_do_an.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.btl_app_dat_do_an.model.Item;

import java.util.ArrayList;
import java.util.List;

public class SQLiteHelperItem extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "Food.db";
    private static final int DATABASE_VERSION = 1;

    public SQLiteHelperItem(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "Create table items(id Integer primary key autoincrement," +
                "name text, describe text, price text, date text)";
        db.execSQL(sql);
    }

    @Override 
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    public long addItem(Item i){
        ContentValues values = new ContentValues();
        values.put("name",i.getName());
        values.put("describe",i.getDescribe());
        values.put("price",i.getPrice());
        values.put("date",i.getDate());
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.insert("items",null,values);
    }

    public List<Item>getAllnoDate(){
        List<Item> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String order = "id DESC";
        Cursor cursor = db.query("items",null,null,null,null,null,order);
        while(cursor!=null && cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String des = cursor.getString(2);
            String price = cursor.getString(3);
            list.add(new Item(id,name,des,price));
        }
        return list;
    }

}