package com.example.btl_app_dat_do_an;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.btl_app_dat_do_an.dal.SQLiteHelper;
import com.example.btl_app_dat_do_an.model.User;

public class UpdateActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText newUsername, newPassword;
    private Button buttonUpdate, buttonDelete;
    private User user;
    SQLiteHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        initView();
        buttonDelete.setOnClickListener(this);
        buttonUpdate.setOnClickListener(this);
        Intent intent = getIntent();
        int userid = intent.getIntExtra("id", -1);
//        boolean userinfo = db.getUserbyID(userid);
//        if(userinfo){
//            Toast.makeText(UpdateActivity.this,"Lấy thành công thông tin người dùng",Toast.LENGTH_SHORT).show();
//            return;
//        }
    }

    public void initView() {
        newUsername = findViewById(R.id.newUName);
        newPassword = findViewById(R.id.newPass);
        buttonUpdate = findViewById(R.id.btUpdatePassAccount);
        buttonDelete = findViewById(R.id.btDeleteAccount);
    }

    @Override
    public void onClick(View v) {
        SQLiteHelper db = new SQLiteHelper(this);
        if (v == buttonDelete) {
            Intent intent = getIntent();
            int userid = intent.getIntExtra("id", -1);
            db.delete(userid);
            finish();
        }
        if (v == buttonUpdate) {
            Intent intent = getIntent();
            int userid = intent.getIntExtra("id", -1);
            String username = newUsername.getText().toString();
            String password = newPassword.getText().toString();
            if (!newUsername.equals("") && !newPassword.equals("")) {
                String role = "Customer";
                User u = new User(userid, username, password, role);
                db = new SQLiteHelper(this);
                db.updatePassword(userid, u);
                finish();
            }
        }
    }
}