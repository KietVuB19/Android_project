package com.example.btl_app_dat_do_an.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.btl_app_dat_do_an.model.Item;

public class SQLiteCartItem extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "CartItem.db";
    private static final int DATABASE_VERSION = 1;
    public SQLiteCartItem(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "Create table cart(id Integer primary key autoincrement," +
                "username text," +
                "password text," +
                "role text," +
                "quantity text)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public long addCartItem(Item i){
        ContentValues values = new ContentValues();
        values.put("name",i.getName());
        values.put("describe",i.getDescribe());
        values.put("price",i.getPrice());
        values.put("date",i.getDate());
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        return sqLiteDatabase.insert("items",null,values);
    }
}
