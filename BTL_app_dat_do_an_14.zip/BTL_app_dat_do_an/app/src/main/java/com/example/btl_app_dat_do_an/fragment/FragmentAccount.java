package com.example.btl_app_dat_do_an.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.btl_app_dat_do_an.AddActivity;
import com.example.btl_app_dat_do_an.MainActivity;
import com.example.btl_app_dat_do_an.R;
import com.example.btl_app_dat_do_an.UpdateActivity;
import com.example.btl_app_dat_do_an.dal.SQLiteHelper;
import com.example.btl_app_dat_do_an.model.User;

public class FragmentAccount extends Fragment {
    private EditText editTextPass, editTextUsername;
    private Button buttonUpdate, buttonCancel;
    private User user;
    SQLiteHelper db;
    public FragmentAccount() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_accout,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        editTextUsername = view.findViewById(R.id.editTextUpdateUserSHOW);
        editTextPass = view.findViewById(R.id.editTextUpdatePassSHOW);
        buttonUpdate = view.findViewById(R.id.btUpdateAccount);
        buttonCancel = view.findViewById(R.id.btCancelAccount);
        db = new SQLiteHelper(getContext());

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), UpdateActivity.class);
                startActivity(intent);
            }
        });
    }
}
