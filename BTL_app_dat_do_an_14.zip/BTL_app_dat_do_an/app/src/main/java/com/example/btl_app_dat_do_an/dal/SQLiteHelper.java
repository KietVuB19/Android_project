package com.example.btl_app_dat_do_an.dal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.example.btl_app_dat_do_an.model.User;

public class SQLiteHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Login.db";
    private static final int DATABASE_VERSION = 1;
    public SQLiteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "Create table users(id Integer primary key autoincrement," +
                "username text," +
                "password text," +
                "role text)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertUser(String username, String password, String role){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username",username);
        contentValues.put("password",password);
        contentValues.put("role",role);
        long result = db.insert("users",null,contentValues);
        return result != -1;
    }
    public boolean checkUsername(String username){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *from users where username = ?",new String[]{username});
        return cursor.getCount() > 0;
    }

    public boolean checkAccount(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select *from users where username = ? and password = ?",new String[]{username,password});
        return cursor.getCount() > 0;
    }

    public int getUserID(String username,String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select id from users where username = ? and password = ?",new String[]{username,password});
        int userId = -1;
        if(cursor.moveToFirst()) {
            userId = cursor.getColumnIndex("id");
        }
        return userId;
    }

    public boolean getUserbyID(int userid){
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT username, password, role FROM users WHERE id = " + userid;
        Cursor cursor = db.rawQuery(selectQuery,null);
        String username = cursor.getString(1);
        String password = cursor.getString(2);
        if(!username.equals("") && !password.equals("")){
            return true;
        }
        else {
            return false;
        }
    }
    public int updatePassword(int userid, User user){
        ContentValues values = new ContentValues();
        values.put("username",user.getUsername());
        values.put("password",user.getPassword());
        values.put("role",user.getRole());
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        String whereClause = "id = ?";
        String[] whereArgs = {Integer.toString(userid)};
        return sqLiteDatabase.update("users",values,whereClause,whereArgs);
    }

    public int delete(int userid){
        SQLiteDatabase sqLiteDatabase = getWritableDatabase();
        String whereClause = "id = ?";
        String[] whereArgs = {Integer.toString(userid)};
        return sqLiteDatabase.delete("users", whereClause, whereArgs);
    }
}
