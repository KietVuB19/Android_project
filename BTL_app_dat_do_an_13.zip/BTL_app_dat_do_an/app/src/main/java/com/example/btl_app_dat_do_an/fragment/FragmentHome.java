package com.example.btl_app_dat_do_an.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;

import com.example.btl_app_dat_do_an.R;
import com.example.btl_app_dat_do_an.adapter.RecycleViewAdapter;
import com.example.btl_app_dat_do_an.dal.SQLiteHelperItem;
import com.example.btl_app_dat_do_an.model.Item;

import java.util.List;

public class FragmentHome extends Fragment{
    private SearchView searchView;
    private RecyclerView recyclerView;
    private RecycleViewAdapter recyclerViewAdapter;
    private SQLiteHelperItem db;
    public FragmentHome() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home,container,false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recycleViewHome);
        searchView = view.findViewById(R.id.search);

        recyclerViewAdapter = new RecycleViewAdapter();
        db = new SQLiteHelperItem(getContext());
        List<Item> list = db.getAllnoDate();
        recyclerViewAdapter.setList(list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(),RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(recyclerViewAdapter);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                List<Item> list = db.searchByName(s);
                recyclerViewAdapter.setList(list);
                return true;
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        List<Item> list = db.getAllnoDate();
        recyclerViewAdapter.setList(list);
    }
}
