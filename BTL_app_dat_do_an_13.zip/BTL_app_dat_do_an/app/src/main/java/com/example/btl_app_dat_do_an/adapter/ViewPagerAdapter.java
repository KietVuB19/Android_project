package com.example.btl_app_dat_do_an.adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.btl_app_dat_do_an.fragment.FragmentCart;
import com.example.btl_app_dat_do_an.fragment.FragmentLogout;
import com.example.btl_app_dat_do_an.fragment.FragmentAccount;
import com.example.btl_app_dat_do_an.fragment.FragmentHome;

public class ViewPagerAdapter extends FragmentStatePagerAdapter {
    public ViewPagerAdapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch(position){
            case 0: return new FragmentHome();
            case 1: return new FragmentCart();
            case 2: return new FragmentAccount();
            case 3: return new FragmentLogout();
        }
        return null;
    }

    @Override
    public int getCount() {
        return 4;
    }
}
