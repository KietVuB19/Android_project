package com.example.btl_app_dat_do_an;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.btl_app_dat_do_an.dal.SQLiteHelper;
import com.example.btl_app_dat_do_an.model.User;

public class UpdateActivity extends AppCompatActivity {

    private EditText currPassword, newPassword;
    private Button buttonUpdate ,buttonDelete;
    private User user;
    SQLiteHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        currPassword = findViewById(R.id.curPass);
        newPassword = findViewById(R.id.newPass);
        buttonUpdate = findViewById(R.id.btUpdatePassAccount);
        buttonDelete = findViewById(R.id.btDeleteAccount);
        String uname = user.getUsername();

        Intent intent = getIntent();
        getSupportActionBar().hide();
        user = (User) intent.getSerializableExtra("user");
        db = new SQLiteHelper(this);
        currPassword.setText(user.getPassword());

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                db.delete(uname);
                finish();
            }
        });
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!currPassword.equals("") && !newPassword.equals("") && newPassword!=currPassword){
                    String username = user.getUsername();
                    String password = newPassword.getText().toString();
                    String role ="Customer";
                    User u =new User(username,password,role);
                    db.updatePassword(u);
                }
            }
        });
    }
}